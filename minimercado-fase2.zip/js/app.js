// Relógio e validação
function atualizaRelogio() {
  const el = document.getElementById('clock');
  if (el) {
    const agora = new Date();
    el.textContent = agora.toLocaleDateString() + ' ' + agora.toLocaleTimeString();
  }
}
setInterval(atualizaRelogio, 1000);
atualizaRelogio();

// Validação de formulários
document.addEventListener('submit', function(event) {
  if (!event.target.checkValidity()) {
    event.preventDefault();
    event.stopPropagation();
  }
  event.target.classList.add('was-validated');
  if (event.target.id === 'formCliente') {
    event.preventDefault();
    document.getElementById('msgOk').classList.remove('d-none');
  }
  if (event.target.id === 'formAgendamento') {
    event.preventDefault();
    const msg = document.getElementById('msgAg');
    msg.textContent = 'Agendamento confirmado!';
    msg.classList.remove('d-none');
  }
});